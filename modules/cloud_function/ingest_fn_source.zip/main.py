"""
Flowterra ingest-fn — Cloud Function 2nd gen (Pub/Sub trigger)

Entry point: ingest_event(cloud_event)

Responsibilities (per ingest-fn.md):
  1. Parse and validate MQTT payload from the Pub/Sub message.
  2. RSSI-to-zone: look up gateway location + area polygon → current area.
  3. Firestore write: upsert live_positions/{tagId}.
  4. BigQuery streaming insert into location_events.
  5. Geofence check: on entry/exit write alerts/{alertId} + send FCM.

TODO(Phase 4): Replace stub implementations with real logic.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import uuid
from datetime import datetime, timezone

import functions_framework
from cloudevents.http import CloudEvent

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ---------------------------------------------------------------------------
# Environment / lazy-initialised clients
# ---------------------------------------------------------------------------

_GCP_PROJECT = os.environ.get("GCP_PROJECT_ID", "")
_BQ_DATASET  = os.environ.get("BQ_DATASET", "flowterra_dev")
_BQ_TABLE    = os.environ.get("BQ_TABLE", "location_events")
_ALERT_TABLE = os.environ.get("ALERTS_TABLE", "geofence_events")

_firestore_client = None
_bq_client        = None


def _firestore():
    global _firestore_client
    if _firestore_client is None:
        from google.cloud import firestore
        _firestore_client = firestore.Client(project=_GCP_PROJECT)
    return _firestore_client


def _bigquery():
    global _bq_client
    if _bq_client is None:
        from google.cloud import bigquery
        _bq_client = bigquery.Client(project=_GCP_PROJECT)
    return _bq_client


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

@functions_framework.cloud_event
def ingest_event(cloud_event: CloudEvent) -> None:
    """
    Triggered by a Pub/Sub message published to flowterra-iot-ingress.
    The Pub/Sub message data is the raw MQTT payload (JSON bytes).
    The MQTT topic is passed as the message attribute ``mqtt_topic``.
    """
    try:
        # 1. Decode Pub/Sub message
        data_b64: str = cloud_event.data["message"]["data"]
        raw_bytes: bytes = base64.b64decode(data_b64)
        mqtt_topic: str = cloud_event.data["message"].get("attributes", {}).get(
            "mqtt_topic", ""
        )

        log.info("Received message from mqtt_topic=%s len=%d", mqtt_topic, len(raw_bytes))

        # 2. Parse payload
        event = _parse_payload(raw_bytes, mqtt_topic)
        if event is None:
            log.warning("Skipping unparseable payload.")
            return

        # 3. Firestore write — live position (non-blocking; errors don't stop BQ)
        try:
            _write_live_position(event)
        except Exception as exc:  # noqa: BLE001
            log.error("Firestore write failed: %s", exc)

        # 4. BigQuery streaming insert
        _insert_location_event(event)

        # 5. Geofence check (stub — implement in follow-up ticket)
        _check_geofence(event)

    except Exception as exc:  # noqa: BLE001
        log.exception("Unhandled error in ingest_event: %s", exc)
        raise  # re-raise so Pub/Sub retries


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_payload(raw: bytes, mqtt_topic: str) -> dict | None:
    """
    Parse raw MQTT payload JSON into a normalised event dict.

    Expected payload schema (from BLE gateway):
    {
      "tagId":     "tag-abc123",
      "gatewayId": "gw-001",
      "rssi":      -72,
      "ts":        1714500000000   // epoch ms
    }

    MQTT topic format: iot/ingress/{customerId}/{siteId}/{floor}/{gatewayId}
    """
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.warning("JSON decode error: %s | raw=%r", exc, raw[:200])
        return None

    # Extract tenant context from MQTT topic
    parts = mqtt_topic.split("/")
    # topic: iot/ingress/{customerId}/{siteId}/...
    customer_id = parts[2] if len(parts) > 2 else "unknown"
    site_id     = parts[3] if len(parts) > 3 else "unknown"

    tag_id     = payload.get("tagId") or payload.get("tag_id")
    gateway_id = payload.get("gatewayId") or payload.get("gateway_id")
    rssi       = payload.get("rssi")
    ts_ms      = payload.get("ts")

    if not all([tag_id, gateway_id, rssi is not None]):
        log.warning("Missing required fields in payload: %s", payload)
        return None

    event_ts = (
        datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
        if ts_ms
        else datetime.now(tz=timezone.utc)
    )

    return {
        "event_id":    str(uuid.uuid4()),
        "customer_id": customer_id,
        "site_id":     site_id,
        "gateway_id":  gateway_id,
        "tag_id":      tag_id,
        "rssi":        int(rssi),
        "area_id":     None,   # populated by _resolve_area (TODO)
        "floor":       None,
        "event_ts":    event_ts,
        "ingested_at": datetime.now(tz=timezone.utc),
        "raw_payload": raw.decode("utf-8", errors="replace"),
    }


def _resolve_area(event: dict) -> dict:
    """
    TODO(Phase 4): Look up gateway location in Firestore sites config and
    compute the tag's current area from the RSSI value and area polygons.
    """
    return event  # pass-through stub


def _write_live_position(event: dict) -> None:
    """Upsert Firestore live_positions/{customerId}_{tagId}."""
    doc_id = f"{event['customer_id']}_{event['tag_id']}"
    _firestore().collection("live_positions").document(doc_id).set(
        {
            "tagId":      event["tag_id"],
            "customerId": event["customer_id"],
            "siteId":     event["site_id"],
            "gatewayId":  event["gateway_id"],
            "areaId":     event["area_id"],
            "rssi":       event["rssi"],
            "updatedAt":  event["event_ts"],
        },
        merge=True,
    )
    log.debug("Firestore upsert: live_positions/%s", doc_id)


def _insert_location_event(event: dict) -> None:
    """Streaming insert into BigQuery location_events table."""
    bq = _bigquery()
    table_ref = f"{_GCP_PROJECT}.{_BQ_DATASET}.{_BQ_TABLE}"

    row = {
        "event_id":    event["event_id"],
        "customer_id": event["customer_id"],
        "site_id":     event["site_id"],
        "gateway_id":  event["gateway_id"],
        "tag_id":      event["tag_id"],
        "rssi":        event["rssi"],
        "area_id":     event["area_id"],
        "floor":       event["floor"],
        "event_ts":    event["event_ts"].isoformat(),
        "ingested_at": event["ingested_at"].isoformat(),
        "raw_payload": event["raw_payload"],
    }

    errors = bq.insert_rows_json(table_ref, [row])
    if errors:
        log.error("BigQuery insert errors: %s", errors)
    else:
        log.debug("BigQuery insert OK: %s", event["event_id"])


def _check_geofence(event: dict) -> None:
    """
    TODO(Phase 4): Load geofence rules from Firestore, compare current area,
    write alert to Firestore alerts/{alertId} and BigQuery geofence_events,
    send FCM push notification.
    """
    pass  # stub
